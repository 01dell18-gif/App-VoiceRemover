__version__ = '2.11.1+cpu'
git_version = '455331b1b3bb4aabfe3228f6f911fc3f11ae93b1'
